# linuxprivchecker
This is a python3 port of the really good linuxprivchecker.py (http://www.securitysift.com/download/linuxprivchecker.py).

It appears to work, but like, no take-backsies.
